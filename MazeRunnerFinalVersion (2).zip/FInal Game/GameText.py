import pygame
from pygame.locals import *

pygame.init()

# make screen dimensions
WIDTH, HEIGHT = 1000, 652
screen = pygame.display.set_mode((WIDTH, HEIGHT))

# set colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)


def show_title_screen():
    screen.fill(WHITE)
    # text info
    font = pygame.font.Font("Hitchcut-Regular.ttf", 48)
    font_small = pygame.font.Font("Hitchcut-Regular.ttf", 22)
    title = font.render("Maze Runner", True, BLACK)
    prompt = font_small.render("Press the space key to continue", True, BLACK)

    # add text on screen
    screen.blit(title, (WIDTH // 2 - title.get_width() // 2, HEIGHT // 3))
    screen.blit(prompt, (WIDTH // 2 - prompt.get_width() // 2, HEIGHT // 2))

    pygame.display.flip()

    # wait for key press
    waiting = True
    while waiting:
        keys = pygame.key.get_pressed()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if keys[pygame.K_SPACE]:
                return "Space"





def instruction_game_screen():
    screen.fill(WHITE)
    running = True
    while running:
        keys=pygame.key.get_pressed()
        #adding instructions
        instructions= pygame.image.load('InstructionsScreen.png').convert()
        screen.blit (instructions,(0,0))
        # handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        if keys[pygame.K_BACKSPACE]:
            return "Back"
        # update display
        pygame.display.flip()

        # control frame rate
        pygame.time.Clock().tick(60)
def LevelTransition(LevelNumber):
    screen.fill((0,0,0))
    running = True
    while running:
        if LevelNumber == 1:
            Transition1 = pygame.image.load('LEVEL 1.png').convert()
            screen.blit(Transition1, (0, 0))
        elif LevelNumber == 2:
            Transition2 = pygame.image.load('LEVEL 2.png').convert()
            screen.blit(Transition2, (0, 0))
        elif LevelNumber == 3:
            Transition3 = pygame.image.load('LEVEL 3.png').convert()
            screen.blit(Transition3, (0, 0))
        pygame.display.flip()
        pygame.time.wait(1000)
        running = False
