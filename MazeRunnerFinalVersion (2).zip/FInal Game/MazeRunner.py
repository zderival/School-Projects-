
import pygame
import sys
import time

from Level1 import Level1
from GameText import show_title_screen
from GameText import instruction_game_screen
from GameText import LevelTransition
from Level2 import Level2
from Level3 import Level3
from pygame.display import update
from pygame.sprite import collide_rect

pygame.init()
pygame.mixer.init()

#Game loop Variables
Menu = True
LevelNum = 1
Count = 0
clock = pygame.time.Clock()
# Set up the display
width, height = 1000, 652
window = pygame.display.set_mode((width, height))
# set colors
WHITE = (255, 255, 255)
BLUE = (127, 150, 200)
BLACK = (0, 0, 0)

# set  font
font = pygame.font.SysFont("Ariel", 48)
font_small = pygame.font.SysFont(None, 36)
BGMusic = pygame.mixer.Sound("Maze runner music.mp3")
BGMusic.set_volume(0.3)

# Define colors
backroundcolor = (0, 255, 255)
charactercolor = (220, 0, 0)
mazecolor = (255,0,255)


# Character settings
x, y = 515, 490
velocity = 5
charactersize = 20

pygame.display.flip()

running = True
while running:
    keys = pygame.key.get_pressed()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    if LevelNum == 1:
        Title = show_title_screen()
        if Title == "Space":
            Instruction = instruction_game_screen()
        if Instruction == "Back":
            LevelTransition(LevelNum)
            BGMusic.play()
            start_time = time.time()
            LevelNum = Level1(start_time)
    if LevelNum == 2:
        LevelTransition(LevelNum)
        start_time = time.time()
        LevelNum = Level2(start_time)
    if LevelNum == 3:
        LevelTransition(LevelNum)
        start_time = time.time()
        LevelNum=Level3(start_time)
    if LevelNum == "Quit":
        running = False
    if LevelNum == "Lose":
        Lose = pygame.image.load('YOU LOSE.png').convert()
        window.blit(Lose, (0, 0))
        pygame.display.flip()
        pygame.time.wait(4000)
        running = False
    if LevelNum == "You Win":
        Win = pygame.image.load('YOU WIN.png').convert()
        window.blit(Win, (0, 0))
        pygame.display.flip()
        pygame.time.wait(4000)
        running = False
    pygame.display.update()


pygame.quit()
sys.exit()