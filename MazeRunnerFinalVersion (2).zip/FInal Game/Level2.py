import pygame
import time


pygame.init()

clock = pygame.time.Clock()
start_time = time.time()
countdown = 30

width, height = 1000, 652
window = pygame.display.set_mode((width, height))
# set colors
WHITE = (255, 255, 255)
BLUE = (127, 150, 200)
BLACK = (0, 0, 0)

backroundcolor = (0, 255, 255)
charactercolor = (220, 0, 0)
mazecolor = (255,0,255)

font = pygame.font.Font("Hitchcut-Regular.ttf", 48)
font_small = pygame.font.Font("Hitchcut-Regular.ttf", 22)


def Level2(Time):
    LevelNum = 2
    score = 0
    key = 0
    gate_unlocked = False

    DoorOpen1 = pygame.mixer.Sound("Door Opening.mp3")
    DoorOpen1.set_volume(0.7)

    character_image = pygame.image.load("pac_man-removebg-preview.png").convert_alpha()
    characterUpdate = pygame.transform.scale(character_image, (40, 40))
    Character = characterUpdate.get_rect()
    Character = Character.move(515, 490)

    Apple = pygame.image.load("th__3_-removebg-preview.png").convert_alpha()
    AppleUpdate = pygame.transform.scale(Apple, (50, 50))
    AppleRect = AppleUpdate.get_rect()
    AppleRect = AppleRect.move(155,200)

    Strawberry = pygame.image.load("th__2_-removebg-preview.png").convert_alpha()
    StrawberryUpdate = pygame.transform.scale(Strawberry, (50, 50))
    StrawberryRect = StrawberryUpdate.get_rect()
    StrawberryRect = StrawberryRect.move(245, 380)

    Orange = pygame.image.load("OIP__1_-removebg-preview.png").convert_alpha()
    OrangeUpdate = pygame.transform.scale(Orange, (50, 50))
    OrangeRect = OrangeUpdate.get_rect()
    OrangeRect = OrangeRect.move(515, 200)

    Crystal = pygame.image.load("funny-cartoon-colorful-fantasy-fruits-set-vector-45735321-removebg-preview.png").convert_alpha()
    CrystalUpdate = pygame.transform.scale(Crystal, (50, 50))
    CrystalRect = CrystalUpdate.get_rect()
    CrystalRect = CrystalRect.move(775, 470)

    keyO = pygame.image.load("goldenkey_2_optimized.png").convert_alpha()
    keyUpdate = pygame.transform.scale(keyO, (30, 30))
    keyRect = keyUpdate.get_rect()
    keyRect = keyRect.move(885, 130)

    gate = pygame.image.load("OIP__4_-removebg-preview.png").convert_alpha()
    gateUpdate = pygame.transform.scale(gate, (75, 75))
    gateRect = gateUpdate.get_rect()
    gateRect = gateRect.move(415, 60)

    Lvl1WinR = pygame.Rect(415, 93, 80, 10)

    Lvl1WinR2 = pygame.Rect(505, 547, 80, 10)

    AllRects=[ pygame.Rect(45, 95, 368, 11),
        pygame.Rect(490, 95, 458, 11),
        pygame.Rect(133, 283, 190, 5),
        pygame.Rect(134, 373, 277, 5),
        pygame.Rect(403, 461, 365, 5),
        pygame.Rect(312, 193, 90, 5),
        pygame.Rect(55, 462, 88, 5),
        pygame.Rect(500, 194, 80, 5),
        pygame.Rect(680, 283, 179, 5),
        pygame.Rect(848, 193, 90, 5),
        pygame.Rect(770, 373, 78, 5),
        pygame.Rect(222, 460, 13, 5),
        pygame.Rect(579, 371, 13, 5),
        pygame.Rect(668, 371, 13, 5),
        pygame.Rect(847, 460, 13, 5),
        pygame.Rect(53, 105, 5, 438),
        pygame.Rect(321, 376, 5, 165),
        pygame.Rect(231, 105, 5, 168),
        pygame.Rect(142, 185, 5, 90),
        pygame.Rect(410, 185, 5, 189),
        pygame.Rect(233, 375, 5, 88),
        pygame.Rect(142, 452, 5, 13),
        pygame.Rect(320, 273, 5, 13),
        pygame.Rect(499, 195, 5, 257),
        pygame.Rect(588, 185, 5, 189),
        pygame.Rect(678, 105, 5, 269),
        pygame.Rect(767, 185, 5, 90),
        pygame.Rect(857, 273, 5, 13),
        pygame.Rect(588, 463, 5, 80),
        pygame.Rect(767, 375, 5, 90),
        pygame.Rect(856, 363, 5, 100),


        # Defining Bottom Rects
        pygame.Rect(55, 540, 447, 5),
        pygame.Rect(590, 540, 347, 5),
        pygame.Rect(402, 450, 358, 5),
        pygame.Rect(55, 450, 90, 5),
        pygame.Rect(134, 362, 267, 5),
        pygame.Rect(145, 272, 177, 5),
        pygame.Rect(133, 183, 12, 5),
        pygame.Rect(312, 183, 100, 5),
        pygame.Rect(490, 183, 100, 5),
        pygame.Rect(680, 272, 178, 5),
        pygame.Rect(758, 362, 100, 5),
        pygame.Rect(848, 183, 90, 5),
        pygame.Rect(758, 184, 12, 5),

        pygame.Rect(936, 105, 5, 438),
        pygame.Rect(847, 373, 5, 90),
        pygame.Rect(759, 185, 5, 90),
        pygame.Rect(759, 364, 5, 90),
        pygame.Rect(847, 184, 5, 13),
        pygame.Rect(669, 105, 5, 269),
        pygame.Rect(580, 195, 5, 178),
        pygame.Rect(580, 463, 5, 90),
        pygame.Rect(491, 185, 5, 267),
        pygame.Rect(401, 195, 5, 170),
        pygame.Rect(401, 453, 5, 11),
        pygame.Rect(313, 375, 5, 167),
        pygame.Rect(312, 185, 5, 11),
        pygame.Rect(223, 105, 5, 170),
        pygame.Rect(223, 373, 5, 90),
        pygame.Rect(134, 185, 5, 98),
        pygame.Rect(134, 364, 5, 10)

     ]

    maze = pygame.image.load('easylvl2.png').convert()
    # Character settings
    x, y = 515, 490
    velocity = 4
    charactersize = 20
    window.fill(WHITE)
    running = True
    while running:
        keys = pygame.key.get_pressed()

        window.blit(maze, (0, 0))
        dx,dy = 0,0
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            dx -= velocity
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            dx += velocity
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            dy -= velocity
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            dy += velocity

        next_position = Character.move(dx, dy)
        collision = False
        for boundary in AllRects:
            if next_position.colliderect(boundary):
                collision = True
                break
        if next_position.colliderect(Lvl1WinR) == True and gate_unlocked == False:
            collision = True
        if next_position.colliderect(Lvl1WinR2) == True and gate_unlocked == False:
            collision = True
        if not collision:
            Character.move_ip(dx, dy)


        keys_text = font_small.render("Key:", True, BLACK)

        elapsed_time = time.time() - Time
        remaining_time = countdown - elapsed_time
        screen_text = font_small.render(f"Time: {remaining_time:.2f}s", True, (0, 0, 0))
        window.blit(screen_text, (10, 10))
        window.blit(keys_text, (950 - keys_text.get_width() - 40, 10))
        window.blit(keyUpdate, keyRect)

        window.blit(characterUpdate, Character)
        window.blit(AppleUpdate, AppleRect)
        window.blit(StrawberryUpdate, StrawberryRect)
        window.blit(OrangeUpdate, OrangeRect)
        window.blit(CrystalUpdate, CrystalRect)

        restart_button = pygame.image.load('restart-icon.png').convert_alpha()
        button_surf_width = 150
        button_surf_height = 150
        button_surface = pygame.Surface((button_surf_width, button_surf_height))
        button_rect2 = pygame.draw.circle(window, (255, 0, 0), (949, 614), 35)
        X_icon = pygame.image.load('X-icon.png').convert_alpha()
        # Resize button
        X_icon_w = int(restart_button.get_width() * 0.15)
        X_icon_h = int(restart_button.get_height() * 0.15)
        X_icon_resize = pygame.transform.scale(X_icon, (X_icon_w, X_icon_h))
        window.blit(X_icon_resize, (925, 590))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_x, mouse_y = pygame.mouse.get_pos()
                if button_rect2.collidepoint((mouse_x, mouse_y)):
                    return "Quit"

        if Character.colliderect(Lvl1WinR) == True and gate_unlocked or Character.colliderect(Lvl1WinR2) == True and gate_unlocked:
            LevelNum +=1
            return LevelNum
        if keyRect.colliderect(Character):
            keyRect = keyRect.move(35, -120)
            DoorOpen1.play()
            key2 = key + 1
            key = key2
            gate_unlocked = True
            print("keys: " + str(key2))
        if not gate_unlocked:
            window.blit(gateUpdate, gateRect)
        if AppleRect.colliderect(Character):
            AppleRect = AppleRect.move(3000, 3000)
            score2 = score + 1
            score = score2
            print("Score: " + str(score2))
        if CrystalRect.colliderect(Character):
            playerspeed2 = velocity + 5
            velocity = playerspeed2
            CrystalRect = CrystalRect.move(3000, 3000)
        if StrawberryRect.colliderect(Character):
            StrawberryRect = StrawberryRect.move(3000, 3000)
            score2 = score + 1
            score = score2
            print("Score: " + str(score2))
        if OrangeRect.colliderect(Character):
            OrangeRect = OrangeRect.move(3000, 3000)
            score2 = score + 1
            score = score2
            print("Score: " + str(score2))
        if remaining_time <=0:
            remaining_time = 0
            return "Lose"
        pygame.display.flip()
        pygame.time.Clock().tick(60)
