import pygame
import time

from pygame.locals import *

pygame.init()

# make screen dimensions
WIDTH, HEIGHT = 1000, 652
screen = pygame.display.set_mode((WIDTH, HEIGHT))

# set colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

font = pygame.font.Font("Hitchcut-Regular.ttf", 48)
font_small = pygame.font.Font("Hitchcut-Regular.ttf", 22)


def Level3(Time):
    key = 0
    gate_unlocked = False
    score = 0
    countdown = 30

    DoorOpen1 = pygame.mixer.Sound("Door Opening.mp3")
    DoorOpen1.set_volume(0.7)

    play = pygame.Rect(520, 500, 20, 20)
    character_image = pygame.image.load("pac_man-removebg-preview.png").convert_alpha()
    characterUpdate = pygame.transform.scale(character_image, (40, 40))
    character_rect = characterUpdate.get_rect()
    character_rect = character_rect.move(play.x, play.y)

    Crystal = pygame.image.load("funny-cartoon-colorful-fantasy-fruits-set-vector-45735321-removebg-preview.png").convert_alpha()
    CrystalUpdate = pygame.transform.scale(Crystal, (50, 50))
    CrystalRect = CrystalUpdate.get_rect()
    CrystalRect = CrystalRect.move(420, 300)

    pear = pygame.image.load("th-removebg-preview.png").convert_alpha()
    pearUpdate = pygame.transform.scale(pear, (90, 90))
    pearRect = pearUpdate.get_rect()
    pearRect = pearRect.move(90, 100)

    lime = pygame.image.load("OIP__2_-removebg-preview.png").convert_alpha()
    limeUpdate = pygame.transform.scale(lime, (50, 50))
    limeRect = limeUpdate.get_rect()
    limeRect = limeRect.move(250, 400)

    keyO = pygame.image.load("goldenkey_2_optimized.png").convert_alpha()
    keyUpdate = pygame.transform.scale(keyO, (30, 30))
    keyRect = keyUpdate.get_rect()
    keyRect = keyRect.move(885, 130)

    gate = pygame.image.load("OIP__4_-removebg-preview.png").convert_alpha()
    gateUpdate = pygame.transform.scale(gate, (75, 75))
    gateRect = gateUpdate.get_rect()
    gateRect = gateRect.move(415, 60)

    Lvl1WinR = pygame.Rect(415, 93, 80, 10)
    Lvl1WinR2 = pygame.Rect(505, 547, 80, 10)




    player_speed = 5
    player_size = 20

    running = True
    while running:
        # adding maze background
        maze = pygame.image.load('easylvl3.png').convert()
        screen.blit(maze, (0, 0))


        toprectl = pygame.Rect(45, 96, 367, 11)
        toprectr = pygame.Rect(490, 96, 460, 11)

        bottomrectl = pygame.Rect(45, 540, 460, 11)
        bottomrectr = pygame.Rect(580, 540, 370, 11)

        siderectl = pygame.Rect(45, 96, 11, 457)
        siderectr = pygame.Rect(938, 90, 11, 457)

        # horizontal rects from left to right
        hori_up1 = pygame.Rect(50, 192, 184, 3.5)
        hori_down1 = pygame.Rect(50, 184, 184, 3.5)

        hori_up2 = pygame.Rect(132, 280, 95, 3.5)
        hori_down2 = pygame.Rect(136, 270, 95, 3.5)
        endcap1 = pygame.Rect(231, 185, 3.5, 12)

        hori_down4 = pygame.Rect(56, 363, 89, 3.5)
        hori_up4 = pygame.Rect(56, 368, 89, 3.5)
        endcap2 = pygame.Rect(133, 272, 3.5, 13)

        hori_up5 = pygame.Rect(135, 458, 188, 3.5)
        hori_down5 = pygame.Rect(135, 452, 188, 3.5)
        endcap3 = pygame.Rect(142, 364, 3.5, 11)

        hori_up6 = pygame.Rect(313, 193, 100, 3.5)
        hori_down6 = pygame.Rect(313, 184, 100, 3.5)
        endcap4 = pygame.Rect(133, 453, 3.5, 11)

        hori_up7 = pygame.Rect(400, 279, 100, 3.5)
        hori_down7 = pygame.Rect(400, 273, 100, 3.5)

        hori_up8 = pygame.Rect(680, 370, 180, 3.5)
        hori_down8 = pygame.Rect(680, 364, 180, 3.5)

        # vertical rects from left to right
        verti_r1 = pygame.Rect(223, 280, 3.5, 169)
        verti_l1 = pygame.Rect(230, 270, 3.5, 173)

        verti_r2 = pygame.Rect(312, 195, 3.5, 268)
        verti_l2 = pygame.Rect(320, 195, 3.5, 268)

        verti_r3 = pygame.Rect(400, 96, 3.5, 87)
        verti_l3 = pygame.Rect(410, 96, 3.5, 100)

        verti_r4 = pygame.Rect(401, 275, 3.5, 190)
        verti_l4 = pygame.Rect(408, 275, 3.5, 190)
        endcap5 = pygame.Rect(401, 460, 11, 3.5)

        verti_r5 = pygame.Rect(489, 185, 3.5, 355)
        verti_l5 = pygame.Rect(496, 185, 3.5, 355)
        endcap6 = pygame.Rect(490, 185, 11, 3.5)

        verti_r6 = pygame.Rect(578, 185, 3.5, 355)
        verti_l6 = pygame.Rect(586, 185, 3.5, 355)
        endcap7 = pygame.Rect(580, 185, 11, 3.5)

        verti_r7 = pygame.Rect(666, 105, 3.5, 360)
        verti_l7 = pygame.Rect(674, 105, 3.5, 360)
        endcap8 = pygame.Rect(669, 460, 11, 3.5)

        verti_r8 = pygame.Rect(758, 105, 3.5, 180)
        verti_l8 = pygame.Rect(769, 105, 3.5, 180)
        endcap0 = pygame.Rect(760, 453, 11, 3.5)

        verti_r9 = pygame.Rect(756, 450, 3.5, 100)
        verti_l9 = pygame.Rect(765, 450, 3.5, 100)
        endcap9 = pygame.Rect(760, 283, 11, 3.5)

        verti_r0 = pygame.Rect(846, 183, 3.5, 280)
        verti_l0 = pygame.Rect(854, 183, 3.5, 280)
        endcap01 = pygame.Rect(848, 185, 11, 3.5)

        endcap02 = pygame.Rect(848, 460, 11, 3.5)

        maze_boundaries = [verti_l0, verti_l1, verti_l2, verti_l3, verti_l4, verti_l5, verti_l6, verti_l7, verti_l8,
                           verti_l9, siderectl, endcap1, endcap3, verti_r0, verti_r1, verti_r2, verti_r3, verti_r4,
                           verti_r5, verti_r6, verti_r7, verti_r8, verti_r9, siderectr, endcap2, endcap4, hori_up1,
                           hori_up2, hori_up4, hori_up5, hori_up6, hori_up7, hori_up8, toprectl, toprectr, endcap5,
                           endcap8, endcap9, endcap02, hori_down1, hori_down2, hori_down4, hori_down5, hori_down6,
                           hori_down7, hori_down8, bottomrectl, bottomrectr, endcap6, endcap7, endcap0, endcap01]

        # Player movement
        keys = pygame.key.get_pressed()
        dx, dy = 0, 0
        if keys[K_a] or keys[K_LEFT]:
            dx = -player_speed
        if keys[K_d] or keys[K_RIGHT]:
            dx = player_speed
        if keys[K_w] or keys[K_UP]:
            dy = -player_speed
        if keys[K_s] or keys[K_DOWN]:
            dy = player_speed

        # Move player and check for collisions with boundaries
        next_position = character_rect.move(dx, dy)
        collision = False
        for boundary in maze_boundaries:
            if next_position.colliderect(boundary):
                collision = True
                break
            if next_position.colliderect(Lvl1WinR) == True and gate_unlocked == False:
                collision = True
            if next_position.colliderect(Lvl1WinR2) == True and gate_unlocked == False:
                collision = True

        # if no collision, move the player
        if not collision:
            character_rect.move_ip(dx, dy)

        elapsed_time = time.time() - Time
        remaining_time = countdown - elapsed_time
        screen_text = font_small.render(f"Time: {remaining_time:.2f}s", True, (0, 0, 0))

        # Render the "Keys:" text on the top right
        keys_text = font_small.render("Keys:", True, BLACK)

        screen.blit(characterUpdate, (character_rect.x, character_rect.y))
        screen.blit(screen_text, (10, 10))
        screen.blit(CrystalUpdate, CrystalRect)
        screen.blit(limeUpdate, limeRect)
        screen.blit(pearUpdate, pearRect)
        screen.blit(keys_text, (950 - keys_text.get_width() - 40, 10))
        screen.blit(keyUpdate, keyRect)

        restart_button = pygame.image.load('restart-icon.png').convert_alpha()
        button_surf_width = 150
        button_surf_height = 150
        button_surface = pygame.Surface((button_surf_width, button_surf_height))
        button_rect2 = pygame.draw.circle(screen, (255, 0, 0), (949, 614), 35)
        X_icon = pygame.image.load('X-icon.png').convert_alpha()
        # Resize button
        X_icon_w = int(restart_button.get_width() * 0.15)
        X_icon_h = int(restart_button.get_height() * 0.15)
        X_icon_resize = pygame.transform.scale(X_icon, (X_icon_w, X_icon_h))
        screen.blit(X_icon_resize, (925, 590))


        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_x, mouse_y = pygame.mouse.get_pos()
                if button_rect2.collidepoint((mouse_x, mouse_y)):
                    return "Quit"

        # Draw maze boundaries for debugging
        if CrystalRect.colliderect(character_rect):
            playerspeed2 = player_speed + 5
            player_speed = playerspeed2
            CrystalRect = CrystalRect.move(3000, 3000)
        if limeRect.colliderect(character_rect):
            limeRect = limeRect.move(3000, 3000)
            score2 = score + 1
            score = score2
            print("Score: " + str(score2))
        if pearRect.colliderect(character_rect):
            pearRect = pearRect.move(3000, 3000)
            score2 = score + 1
            score = score2
            print("Score: " + str(score2))
        if character_rect.colliderect(Lvl1WinR) == True and gate_unlocked:
            LevelNum = "You Win"
            return LevelNum
        if keyRect.colliderect(character_rect):
            keyRect = keyRect.move(35, -120)
            DoorOpen1.play()
            key2 = key + 1
            key = key2
            gate_unlocked = True
            print("keys: " + str(key2))
        if not gate_unlocked:
            screen.blit(gateUpdate, gateRect)
        if remaining_time <=0:
            remaining_time = 0
            return "Lose"

        pygame.display.flip()
        pygame.time.Clock().tick(60)
