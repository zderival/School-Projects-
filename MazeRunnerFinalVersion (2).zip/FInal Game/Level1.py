import pygame
import time
from pygame.locals import *


pygame.init()
pygame.mixer.init()

clock = pygame.time.Clock()
start_time = time.time()
# make screen dimensions
WIDTH, HEIGHT = 1000, 652
screen = pygame.display.set_mode((WIDTH, HEIGHT))

# set colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

countdown = 20
font = pygame.font.Font("Hitchcut-Regular.ttf", 48)
font_small = pygame.font.Font("Hitchcut-Regular.ttf", 22)


# function that runs main game
def Level1(Time):
    screen.fill(WHITE)
    LevelNum = 1
    key = 0
    gate_unlocked = False
    score = 0

    Buttonwidth = 25
    Buttonheight = 25

    # Load maze background
    maze = pygame.image.load('easylvl.png').convert()
    DoorOpen1 = pygame.mixer.Sound("Door Opening.mp3")
    DoorOpen1.set_volume(0.7)

    fruit = pygame.image.load("OIP-removebg-preview.png").convert_alpha()
    fruitUpdate = pygame.transform.scale(fruit, (50, 60))
    fruitRect = fruitUpdate.get_rect()
    fruitRect = fruitRect.move(70, 120)

    banana = pygame.image.load("th__1_-removebg-preview.png").convert_alpha()
    bananaUpdate = pygame.transform.scale(banana, (60, 60))
    bananaRect = bananaUpdate.get_rect()
    bananaRect = bananaRect.move(95, 485)


    character_image = pygame.image.load("pac_man-removebg-preview.png").convert_alpha()
    characterUpdate = pygame.transform.scale(character_image, (40, 40))
    character_rect = characterUpdate.get_rect()
    character_rect = character_rect.move(540, 400)

    keyO = pygame.image.load("goldenkey_2_optimized.png").convert_alpha()
    keyUpdate = pygame.transform.scale(keyO, (30, 30))
    keyRect = keyUpdate.get_rect()
    keyRect = keyRect.move(885, 130)

    gate = pygame.image.load("OIP__4_-removebg-preview.png").convert_alpha()
    gateUpdate = pygame.transform.scale(gate, (75, 75))
    gateRect = gateUpdate.get_rect()
    gateRect = gateRect.move(415, 60)

    Lvl1WinR = pygame.Rect(415, 93, 80, 10)

    Lvl1WinR2 = pygame.Rect(505, 547, 80, 10)

    # puts the boundaries in a list
    maze_boundaries = [
        pygame.Rect(0, -1, 1000, 1),  # Top wall boundary
        pygame.Rect(0, 651, 1000, 1),  # Bottom wall
        pygame.Rect(-1, 0, 1, 652),  # Left wall
        pygame.Rect(1000, 0, 1, 1000),  # Right wall
        #  internal walls boundaries
        pygame.Rect(50, 97, 362, 5),  #    outer left  wall
        pygame.Rect(495, 97, 460, 7), # outer top right wall
        pygame.Rect(45,100,1,455), # outer left wall
        pygame.Rect(45,548,450,8),#bottom outer left wall
        pygame.Rect(952,100,1,455), # outer right wall
        pygame.Rect(590,550,350,6),#very bottom right wall
        pygame.Rect(50,458,272,8), #above the very bottom left wall
        pygame.Rect(229,367,1,96), # small vertical wall left
        pygame.Rect(132,190,5,185),# vertical wall
        pygame.Rect(135, 185, 95, 5),  # horiz wall
        pygame.Rect(225,185,5,100),#vertical wall
        pygame.Rect(223,275,100,5),#vertical wall
        pygame.Rect(321,280,1,90),#vertical wall
        pygame.Rect(322,367,180,1), #horiz wall
        pygame.Rect(406,367,8,100),#vertical wall
        pygame.Rect(496,368,7,180), #vertical wall
        pygame.Rect(502,460,92,1), #horiz wall
        pygame.Rect(859,189,100,1),#horiz wall
        pygame.Rect(859,370,100,1),#horiz wall
        pygame.Rect(677,100,6 ,185), #vertical wall
        pygame.Rect(677,280,185,1),#horiz wall
        pygame.Rect(767,186,10,273),#vertical wall
        pygame.Rect(770,463,95,1), #horiz wall
        pygame.Rect(317,185,275,7), #horiz wall
        pygame.Rect(410,277,181,4),#horiz wall
        pygame.Rect(589,277,5,98),#vertical wall
        pygame.Rect(589,370,96,5), #horiz wall
        pygame.Rect(678,370,6,180), #vertical wall


        pygame.Rect(405, 200, 5, 80),  #  vertical wall
    ]

    player_size = 20
    player_speed = 5

    running = True
    while running:
        screen.fill(WHITE)
        screen.blit(maze, (0, 0))
        screen.blit(fruitUpdate, fruitRect)
        screen.blit(bananaUpdate, bananaRect)

        # Player movement
        keys = pygame.key.get_pressed()
        dx, dy = 0, 0
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            dx -= player_speed
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            dx += player_speed
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            dy -= player_speed
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            dy += player_speed

        # Move player and check for collisions with boundaries
        next_position = character_rect.move(dx, dy)
        collision = False
        for boundary in maze_boundaries:
            if next_position.colliderect(boundary):
                collision = True
                break
        if next_position.colliderect(Lvl1WinR) == True and gate_unlocked == False:
            collision = True
        if next_position.colliderect(Lvl1WinR2) == True and gate_unlocked == False:
            collision = True


        # if no collision, move the player
        if not collision:
            character_rect.move_ip(dx, dy)

        # Render the "Keys:" text on the top right
        keys_text = font_small.render("Key:", True, BLACK)

        elapsed_time = time.time() - Time
        remaining_time = countdown - elapsed_time
        screen_text = font_small.render(f"Time: {remaining_time:.2f}s", True,(0,0,0))

        screen.blit(screen_text, (10, 10))
        screen.blit(keys_text, (950- keys_text.get_width() - 40, 10))
        screen.blit(keyUpdate, keyRect)
        screen.blit(characterUpdate, character_rect)

            # Font
        restart_button = pygame.image.load('restart-icon.png').convert_alpha()
        button_surf_width = 150
        button_surf_height = 150
        button_surface = pygame.Surface((button_surf_width, button_surf_height))
        button_rect2 = pygame.draw.circle(screen, (255,0,0), (949, 614), 35)
        X_icon = pygame.image.load('X-icon.png').convert_alpha()
            # Resize button
        X_icon_w = int(restart_button.get_width() * 0.15)
        X_icon_h = int(restart_button.get_height() * 0.15)
        X_icon_resize = pygame.transform.scale(X_icon, (X_icon_w, X_icon_h))
        screen.blit(X_icon_resize, (925, 590))


        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_x, mouse_y = pygame.mouse.get_pos()
                if button_rect2.collidepoint((mouse_x, mouse_y)):
                    return "Quit"

        # Draw maze boundaries for debugging
        for boundary in maze_boundaries:
            pygame.draw.rect(screen, (0, 0, 0), boundary, 1)

        if keyRect.colliderect(character_rect):
            DoorOpen1.play()
            keyRect = keyRect.move(35, -120)
            key2 = key + 1
            key = key2
            gate_unlocked = True
            print("keys: " + str(key2))
        if not gate_unlocked:
            screen.blit(gateUpdate, gateRect)
        if character_rect.colliderect(Lvl1WinR) == True and gate_unlocked or character_rect.colliderect(Lvl1WinR2) == True and gate_unlocked:
            x, y = 515, 490
            LevelNum += 1
            return LevelNum
        if fruitRect.colliderect(character_rect):
            player_speed2 = player_speed + 5
            player_speed = player_speed2
            fruitRect = fruitRect.move(3000, 3000)
            score2 = score + 1
            score = score2
            print("Score: " + str(score2))
        if bananaRect.colliderect(character_rect):
            bananaRect = bananaRect.move(3000, 3000)
            score2 = score + 1
            score = score2
            print("Score: " + str(score2))
        if remaining_time <=0:
            remaining_time = 0
            return "Lose"
        pygame.display.flip()
        pygame.time.Clock().tick(60)






